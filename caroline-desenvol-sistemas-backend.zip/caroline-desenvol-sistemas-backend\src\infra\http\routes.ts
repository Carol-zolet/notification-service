﻿import { Router } from 'express';
import { NotificationController } from './controllers/notification.controller';
import { ScheduleNotificationUseCase } from '../../application/use-cases/schedule-notification.use-case';
import { InMemoryNotificationRepository } from '../database/repositories/in-memory-notification.repository';

const router = Router();

// Repositório
const notificationRepo = new InMemoryNotificationRepository();

// Use cases
const scheduleUseCase = new ScheduleNotificationUseCase(notificationRepo);

// Controllers
const notificationController = new NotificationController(scheduleUseCase);

// Rotas
router.post('/notifications/schedule', (req, res) => notificationController.schedule(req, res));

router.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

export default router;
