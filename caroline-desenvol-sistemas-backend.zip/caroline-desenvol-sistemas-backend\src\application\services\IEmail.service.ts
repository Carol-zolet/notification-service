// Contrato (Interface) para o servi�o de email (Padr�o Adapter - Aula 2)
export abstract class IEmailService {
  abstract sendMail(
    to: string,
    name: string,
    subject: string,
    body: string,
  ): Promise<void>;
}
